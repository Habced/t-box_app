package com.example.tboxapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
